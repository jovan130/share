"""Tests for dependency utilities."""
